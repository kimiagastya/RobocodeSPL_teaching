package jab.module;

/**
 * Radar
 * 
 * @author jab
 */
public class Radar extends Part {

	public Module bot;

	public Radar(Module bot) {
		this.bot = bot;
	}

	public void scan() {
	}

}
