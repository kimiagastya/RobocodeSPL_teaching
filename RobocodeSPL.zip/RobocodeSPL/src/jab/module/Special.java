package jab.module; 

/**
 * Special
 * 
 * @author jab
 */
public  class  Special  extends Part {
	

	public Module bot;

	

	public Special(Module bot) {
		this.bot = bot;
	}

	

	public void doIt() {
	}


}
