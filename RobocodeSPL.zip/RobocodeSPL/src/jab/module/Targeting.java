package jab.module; 

/**
 * Targeting
 * 
 * @author jabier.martinez
 */
public  class  Targeting  extends Part {
	

	public Module bot;

	

	public Targeting(Module bot) {
		this.bot = bot;
	}

	

	public void target() {
	}


}
